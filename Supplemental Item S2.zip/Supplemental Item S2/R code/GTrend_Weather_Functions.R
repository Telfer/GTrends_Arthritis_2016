## GTrend_Weather_Functions

# Author: Scott Telfer 
# Last update 2016/05/13

# Description: These functions are designed to help format, process and analyse
# Google trend data to determine if there is an increase in arthritis related
# search terms during times of elevated humidity

# =============================================================================

## Load required libraries
library(MatchIt)
library(weathermetrics)

# =============================================================================

#' Format weather data
#' 
#' @param x The file path to the folder containing the weather information
#' @param region_list The locations to be used
#' @param wea_var The weather variable to be extracted and processed. 9 =
#'   humidity, 20 = rain, 6 = dew point, 3 = mean temp
#' @param n_timepoints The total number of time points to be output
#' @param weekly The time period to be used. Weekly only option at the moment
format_weather <- function(x, region_list, wea_var = 9, n_timepoints = 260, 
                           weekly = TRUE) {
  # Set up output data frame and sequences
  weather_df <- matrix(NA, nrow = n_timepoints, ncol = length(region_list))
  weather_df <- as.data.frame(weather_df)
  if (weekly == TRUE) {weekly_seq <- seq(from = 8, by = 7, length.out = 260)}
  
  # Import data
  for (i in 1:length(region_list)) {
    weather_files <- list.files(x, paste0(region_list[[i]], "_201"))
    weather <- c()
    for (j in 1:length(weather_files)) {
      weather_data <- read.csv(paste0(x, "/", weather_files[[j]]), 
                               header = TRUE, stringsAsFactors = FALSE)
      weather_yr <- weather_data[ , wea_var]
      if (wea_var == 20) {
        weather_yr[weather_yr == "T"] = "0"
        weather_yr <- as.numeric(weather_yr)
        weather_yr <- weather_yr * 25.4
      }
      weather <- c(weather, weather_yr)
    }
    
    # Make weekly
    weather_weekly <- c()
    for (k in 1:length(weekly_seq)) {
      weather_week <- mean(weather[(weekly_seq[k] - 6): weekly_seq[k]], 
                           na.rm = TRUE, stringsAsFactors = FALSE)
      weather_weekly <- c(weather_weekly, weather_week)
    }
    if (wea_var == 6 | wea_var == 3) {
      weather_weekly <- fahrenheit.to.celsius(weather_weekly)
    }
    weather_df[ , i] <- weather_weekly
  }
  
  # Return data frame containing all weather variable data for time period
  return(weather_df)
}


# =============================================================================

#' Format gtrends data
#' 
#' @param x The file path to the folder containing the weather information
#' @param region_list The locations to be used
#' @param start Start week of the trends data in the format "yyyy-mm-dd -
#'   yyyy-mm-dd"
#' @param end End week of the trends data in the format "yyyy-mm-dd -
#'   yyyy-mm-dd"
#' @param n_timepoints The total number of time points to be output
format_gtrends <- function(x, region_list, start, end, n_timepoints = 260) {
  gtrends_data <- matrix(NA, nrow = n_timepoints, ncol = length(region_list))
  gtrends_data <- as.data.frame(gtrends_data)
  
  # Format
  for (i in 1:length(region_list)) {
    gt <- read.csv(paste0(x, region_list[[i]], ".csv"), 
                   header = FALSE, stringsAsFactors = FALSE)
    if (nrow(gt) > 200) {
      if (any(grepl(end, gt[, 1])) == TRUE) {
        # trim off top and bottom
        start_pt <- grep(start, gt[, 1]) 
        end_pt <- grep(end, gt[, 1])
        gt1 <- as.numeric(gt[start_pt:end_pt, 2])
        gt1_norm <- 100/mean(gt1)
        gt1 <- gt1 * gt1_norm
        gtrends_data[ , i] <- gt1
      }
    }
    else if (nrow(gt) < 200) {gtrends_data[, i] <- rep(0, times = 260)}
  }
  # Return gtrends data frame
  return(gtrends_data)
}


# =============================================================================

#' Matched propensity analysis of weather and trend data
#' 
#' @param gtrends_data Formatted trend data. A data frame with columns
#'   representing cities and rows time points
#' @param region_list The locations to be used
#' @param weather_data Formatted weather data. A data frame with columns
#'   representing cities and rows time points
#' @param rain_data Formatted weather data. A data frame with columns
#'   representing cities and rows time points
#' @param seasonality Include seasonality component Default TRUE
gtrend_weather_analysis <- function(gtrends_data, region_list, weather_data,
                                    rain_data, seasonality = TRUE) {
  
  # pre-process identify gtrends without zero periods
  city_list_whole_a <- rep(NA, times = length(region_list))
  for (i in 1:length(region_list)) {
    city_list_whole_a[i] <- 0 %in% gtrends_data[, i]
  }
  city_list_whole <- which(city_list_whole_a == FALSE)
  
  # pre-process: identify weather time series without NaN values
  city_list_whole_b <- rep(NA, times = length(city_list_whole))
  for (j in seq_along(city_list_whole)) {
    if (!NaN %in% weather_data[, city_list_whole[j]] == TRUE) {
      city_list_whole_b[j] = TRUE
    } else {
      city_list_whole_b[j] = FALSE
    }
  }
  city_list_whole <- city_list_whole[which(city_list_whole_b == TRUE)]
  
  # which cities have at least 30 data points in the top 75%
  weather_data2 <- weather_data[, city_list_whole]
  weather_data_vec <- as.vector(as.matrix(weather_data)) 
  gg <- quantile(weather_data_vec, c(0.6, 0.75), na.rm = TRUE)
  threshold <- as.numeric(gg[2]) # determine 75% cut off for data
  threshold_low <- as.numeric(gg[1]) # determine 60% cut off for data
  city_list_whole_c <- rep(NA, times = length(city_list_whole))
  for (k in seq_along(city_list_whole)) {
    count <- sum(weather_data[, city_list_whole[k]] > threshold)
    city_list_whole_c[k] <- count > 29
  }
  city_list_whole <- city_list_whole[which(city_list_whole_c == TRUE)]
  
  # prep results matrix and lists
  res_matrix <- matrix(NA, nrow = length(city_list_whole), ncol = 6)
  low_list <- list()
  high_list <- list()
  
  # Main data formatting and analysis
  results <- list()
  
  # de-trend gtrends data
  for (ii in seq_along(city_list_whole)) {
    detr <- gtrends_data[, city_list_whole[ii]]
    detr_ts <- ts(detr, frequency = 52)
    detr_stl <- stl(detr_ts, s.window = "periodic")
    if (seasonality == TRUE) {
      detr_DT <- detr_stl$time.series[, 1] + detr_stl$time.series[, 3]
    } else if (seasonality == FALSE) {
      detr_DT <- detr_stl$time.series[, 3]
    }
    
    # Create dummy variable for weather data
    weather_level <- rep(2, times = 260)
    for (jj in 1:260) {
      if (weather_data[jj, city_list_whole[ii]] > threshold) {
        weather_level[jj] <- 1
      }
      if(weather_data[jj, city_list_whole[ii]] < threshold_low) {
        weather_level[jj] <- 0
      }
    }
    
    # create dummy variable for months
    month_vec <- c(1, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5,
                   5, 5, 6, 6, 6, 6, 7, 7, 7, 7, 7, 8, 8, 8, 8, 9, 9, 9, 9, 10,
                   10, 10, 10, 10, 11, 11, 11, 11, 12, 12, 12, 12, 1, 1, 1, 1,
                   1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 4, 5, 5, 5, 5, 6, 6,
                   6, 6, 7, 7, 7, 7, 7, 8, 8, 8, 8, 9, 9, 9, 9, 9, 10, 10, 10,
                   10, 11, 11, 11, 11, 12, 12, 12, 12, 12, 1, 1, 1, 1, 2, 2, 2,
                   2, 3, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 6, 6, 6, 6, 6, 7,
                   7, 7, 7, 8, 8, 8, 8, 9, 9, 9, 9, 9, 10, 10, 10, 10, 11, 11,
                   11, 11, 12, 12, 12, 12, 12, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3,
                   3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 6, 6, 6, 6, 6, 7, 7, 7, 7, 8,
                   8, 8, 8, 8, 9, 9, 9, 9, 10, 10, 10, 10, 11, 11, 11, 11, 11,
                   12, 12, 12, 12, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 3, 4, 4,
                   4, 4, 5, 5, 5, 5, 5, 6, 6, 6, 6, 7, 7, 7, 7, 8, 8, 8, 8, 8,
                   9, 9, 9, 9, 10, 10, 10, 10, 11, 11, 11, 11, 11, 12, 12, 12)
    
    # combine into dataframe
    df <- data.frame(treat = weather_level, 
                     weather = weather_data[, city_list_whole[ii]], 
                     rain = rain_data[, city_list_whole[ii]], 
                     gtrend = gtrends_data[, city_list_whole[ii]], 
                     month = month_vec)
    
    # remove middle values
    highNlow <- with(df, which(treat %in% c(0, 1)))
    df <- df[highNlow, ]
    
    # Find matches
    m.out <- matchit(treat ~ rain + month, data = df, 
                     method = "nearest", distance = "logit")
    
    # Select matched groups
    weather_h <- match.data(m.out, group = "treat")
    weather_l <- match.data(m.out, group = "control")
    
    # Compare groups
    compare_p <- t.test(weather_h$gtrend, weather_l$gtrend)
    
    # add to results matrix
    res_matrix[ii, 1] <- as.character(city_list_arth[city_list_whole[ii]])
    res_matrix[ii, 2] <- as.numeric(compare_p[3]) # p val
    CI_95 <- compare_p[4]
    res_matrix[ii, 3] <- CI_95[[1]][1]
    res_matrix[ii, 4] <- CI_95[[1]][2]
    mean_gt <- compare_p[5] 
    res_matrix[ii, 5] <- mean_gt[[1]][1]
    res_matrix[ii, 6] <- mean_gt[[1]][2]
    
    # Store high and low groups
    high_list[[ii]] <- weather_h
    low_list[[ii]] <- weather_l
  }
  
  # Make res_matrix into dataframe and name columns
  res_matrix <- as.data.frame(res_matrix)
  colnames(res_matrix) <- c("City", "p_val", "CI95_min", "CI95_max", 
                            "weather_high", "weather_low")
  
  # make output list
  output_list <- list(res_matrix, high_list, low_list)
  
  return(output_list)
}


# =============================================================================

#' Relationship between weather and trend data
#' 
#'  @param x Results list from gtrend_weather_analysis function
#'  @param plot Plot the results
gtrend_weather_analysis2 <- function(x, plot = FALSE) {
  # high list
  high_list <- x[[2]]
  
  # low list
  low_list <- x[[3]]
  
  # combine all city datasets
  high_comb <- high_list[[1]]
  for (i in 2:length(high_list)) {
    high_comb <- rbind(high_comb, high_list[[i]])
  }
  
  low_comb <- low_list[[1]]
  for (i in 2:length(low_list)) {
    low_comb <- rbind(low_comb, low_list[[i]])
  }
  
  comb_df <- rbind(high_comb, low_comb)
  comb_df <- comb_df[, c(2,4)]
  
  # run linear model on data
  fit <- lm(comb_df[, 1] ~ comb_df[, 2])
  
  # plot if required
  if (plot == TRUE) {
    plot(comb_df[, 2], comb_df[, 1])
    abline(fit)
  }
  
  # extract and save p and r^2 values
  p_val <- summary(fit)$coefficients[2, 4] 
  r_sqr <- summary(fit)$r.squared
  grad <- summary(fit)$coefficients[2, 1]
  
  # return results
  res <- list(p_val, r_sqr, grad, fit)
  return(res)
} 
