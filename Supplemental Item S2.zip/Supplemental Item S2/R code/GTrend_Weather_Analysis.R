## GTrend_Weather_Analysis

# Author: Scott Telfer 
# Last update 2016/05/13

# Description: This script formats, processes, and analyses Google trend data to
# determine if there is an increase in arthritis related search terms during
# times of elevated humidity

# =============================================================================

# =============================================================================

## ASSOCIATED DATA WAS SOURCED FROM

# Google trends data from- 
# www.google.co.uk/trends

# Weather data from 
# www.wunderground.com

# =============================================================================

## WORKFLOW
# 1. Load and format list of cities
# 2. Load and format weather data
# 3. Load and format Google Trends data
# 4. test for differences during times of elevated humidity 
# 5. run linear regression models


# =============================================================================

## 1. Load and format cities. Those without matching google trend data have 
# been removed
data_path <- paste0(getwd(),"/all_data")
city_list_arth <- list.files(paste0(data_path, "/trend_data/arthritis"))
city_list_arth <- lapply(city_list_arth, function(x) gsub(".csv", "", x))
city_list_knee <- list.files(paste0(data_path, "/trend_data/knee_pain"))
city_list_knee <- lapply(city_list_knee, function(x) gsub(".csv", "", x))
city_list_hip <- list.files(paste0(data_path, "/trend_data/hip_pain"))
city_list_hip <- lapply(city_list_hip, function(x) gsub(".csv", "", x))


# =============================================================================

## 2. Format weather data
data_path_wea <- paste0(data_path, "/weather_data")

# Humidity data
humidity_data <- format_weather(data_path_wea, city_list_arth, wea_var = 9)

# dew point data
dewpoint_data <- format_weather(data_path_wea, city_list_arth, wea_var = 6)

# Rain data
rain_data <- format_weather(data_path_wea, city_list_arth, wea_var = 20)

# temp data
temp_data <- format_weather(data_path_wea, city_list_arth, wea_var = 3)

# pressure data
press_data <- format_weather(data_path_wea, city_list_arth, wea_var = 12)


# ============================================================================

## 3. Format GTrend data
# Dates
start <- "2011-01-02 - 2011-01-08" 
end <- "2015-12-20 - 2015-12-26"

# Arthritis
data_path_gtrends <- paste0(data_path, "/trend_data", "/arthritis/")
gtrends_data_arthritis <- format_gtrends(data_path_gtrends, city_list_arth,  
                                         start, end)

# Knee pain
data_path_gtrends <- paste0(data_path, "/trend_data", "/knee_pain/")
gtrends_data_knee <- format_gtrends(data_path_gtrends, city_list_knee, 
                                    start, end)

# Hip pain
data_path_gtrends <- paste0(data_path, "/trend_data", "/hip_pain/")
gtrends_data_hip <- format_gtrends(data_path_gtrends, city_list_hip, 
                                   start, end)


# =============================================================================

# 4. Test for differences during times of elevated weather variables
# ARTHRITIS searches
arth_hum_res <- gtrend_weather_analysis(gtrends_data_arthritis, city_list_arth,
                                    humidity_data, rain_data, 
                                    seasonality = TRUE)
arth_dew_res <- gtrend_weather_analysis(gtrends_data_arthritis, city_list_arth,
                                         dewpoint_data, rain_data,
                                         seasonality = TRUE)
arth_temp_res <- gtrend_weather_analysis(gtrends_data_arthritis, city_list_arth,
                                          temp_data, rain_data,
                                          seasonality = TRUE)

# KNEE PAIN searches
knee_hum_res <- gtrend_weather_analysis(gtrends_data_knee, city_list_knee,
                                    humidity_data, rain_data,
                                    seasonality = TRUE)
knee_dew_res <- gtrend_weather_analysis(gtrends_data_knee, city_list_knee,
                                        dewpoint_data, rain_data,
                                        seasonality = TRUE)
knee_temp_res <- gtrend_weather_analysis(gtrends_data_knee, city_list_knee,
                                         temp_data, rain_data,
                                         seasonality = TRUE)

# HIP PAIN searches
hip_hum_res <- gtrend_weather_analysis(gtrends_data_hip, city_list_hip,
                                       humidity_data, rain_data,
                                       seasonality = TRUE)
hip_dew_res <- gtrend_weather_analysis(gtrends_data_hip, city_list_hip,
                                       dewpoint_data, rain_data,
                                       seasonality = TRUE)
hip_temp_res <- gtrend_weather_analysis(gtrends_data_hip, city_list_hip,
                                        temp_data, rain_data,
                                        seasonality = TRUE)


# =============================================================================

# 5. Run linear regressions
arth_lm_hum_res <- gtrend_weather_analysis2(arth_hum_res)
arth_lm_dew_res <- gtrend_weather_analysis2(arth_dew_res)
arth_lm_temp_res <- gtrend_weather_analysis2(arth_temp_res)
knee_lm_hum_res <- gtrend_weather_analysis2(knee_hum_res)
knee_lm_dew_res <- gtrend_weather_analysis2(knee_dew_res)
knee_lm_temp_res <- gtrend_weather_analysis2(knee_temp_res)
hip_lm_hum_res <- gtrend_weather_analysis2(hip_hum_res)
hip_lm_dew_res <- gtrend_weather_analysis2(hip_dew_res)
hip_lm_temp_res <- gtrend_weather_analysis2(hip_temp_res)

# get 95% CIs
knee_dew_CI <- confint(knee_lm_dew_res[[4]], level = 0.95)
knee_temp_CI <- confint(knee_lm_temp_res[[4]], level = 0.95)
hip_dew_CI <- confint(hip_lm_dew_res[[4]], level = 0.95)
hip_temp_CI <- confint(hip_lm_temp_res[[4]], level = 0.95)

# =============================================================================
