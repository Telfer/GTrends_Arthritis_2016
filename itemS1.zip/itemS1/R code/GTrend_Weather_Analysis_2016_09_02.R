## GTrend_Weather_Analysis

# Author: Scott Telfer 
# Last update 2016/05/13

# Description: This script formats, processes, and analyses Google trend data to
# determine if there is an increase in arthritis related search terms during
# times of elevated humidity

# =============================================================================

# =============================================================================

## ASSOCIATED DATA WAS SOURCED FROM

# Google trends data from- 
# www.google.co.uk/trends

# Weather data from 
# www.wunderground.com

# =============================================================================

## WORKFLOW
# 1. Load and format list of cities
# 2. Load and format weather data
# 3. Load and format Google Trends data
# 4. test for differences during times of elevated humidity 
# 5. run linear regression models


# =============================================================================

## 1. Load and format cities. Those without matching google trend data have 
# been removed
data_path <- paste0(getwd(),"/all_data")
city_list_knee <- list.files(paste0(data_path, "/trend_data/knee_pain"))
city_list_knee <- lapply(city_list_knee, function(x) gsub(".csv", "", x))
city_list_hip <- list.files(paste0(data_path, "/trend_data/hip_pain"))
city_list_hip <- lapply(city_list_hip, function(x) gsub(".csv", "", x))
city_list_arth <- list.files(paste0(data_path, "/trend_data/arthritis"))
city_list_arth <- lapply(city_list_arth, function(x) gsub(".csv", "", x))
city_list_radio <- list.files(paste0(data_path, "/trend_data/radio"))
city_list_radio <- lapply(city_list_radio, function(x) gsub(".csv", "", x))


# =============================================================================

## 2. Format weather data
data_path_wea <- paste0(data_path, "/weather_data")

# Humidity data
humidity_data <- format_weather(data_path_wea, city_list_arth, wea_var = 9)

# Rain data
rain_data <- format_weather(data_path_wea, city_list_arth, wea_var = 20)

# temp data
temp_data <- format_weather(data_path_wea, city_list_arth, wea_var = 3)

# pressure data
press_data <- format_weather(data_path_wea, city_list_arth, wea_var = 12)


# ============================================================================

## 3. Format GTrend data
# Dates
start <- "2011-01-02 - 2011-01-08" 
end <- "2015-12-20 - 2015-12-26"

# Knee pain
data_path_gtrends <- paste0(data_path, "/trend_data", "/knee_pain/")
gtrends_data_knee <- format_gtrends(data_path_gtrends, city_list_knee, 
                                    start, end)

# Hip pain
data_path_gtrends <- paste0(data_path, "/trend_data", "/hip_pain/")
gtrends_data_hip <- format_gtrends(data_path_gtrends, city_list_hip, 
                                   start, end)

# Arthritis
data_path_gtrends <- paste0(data_path, "/trend_data", "/arthritis/")
gtrends_data_arthritis <- format_gtrends(data_path_gtrends, city_list_arth,  
                                         start, end)

# Radio
data_path_gtrends <- paste0(data_path, "/trend_data", "/radio/")
gtrends_data_radio <- format_gtrends(data_path_gtrends, city_list_radio,  
                                        start, end)


# =============================================================================

# 4. Test for differences during times of elevated weather variables
# KNEE PAIN searches
knee_hum_res <- gtrend_weather_analysis(gtrends_data_knee, city_list_knee,
                                        humidity_data, rain_data,
                                        seasonality = TRUE, quart = "top")
knee_press_res <- gtrend_weather_analysis(gtrends_data_knee, city_list_knee,
                                          press_data, rain_data,
                                          seasonality = TRUE, quart = "top")
knee_temp_res <- gtrend_weather_analysis(gtrends_data_knee, city_list_knee,
                                         temp_data, rain_data,
                                         seasonality = TRUE, quart = "top")

# HIP PAIN searches
hip_hum_res <- gtrend_weather_analysis(gtrends_data_hip, city_list_hip,
                                       humidity_data, rain_data,
                                       seasonality = TRUE, quart = "top")
hip_press_res <- gtrend_weather_analysis(gtrends_data_hip, city_list_hip,
                                         press_data, rain_data,
                                         seasonality = TRUE, quart = "top")
hip_temp_res <- gtrend_weather_analysis(gtrends_data_hip, city_list_hip,
                                        temp_data, rain_data,
                                        seasonality = TRUE, quart = "top")

# ARTHRITIS searches
arth_hum_res <- gtrend_weather_analysis(gtrends_data_arthritis, city_list_arth,
                                        humidity_data, rain_data, 
                                        seasonality = TRUE, quart = "top")
arth_press_res <- gtrend_weather_analysis(gtrends_data_arthritis, city_list_arth,
                                          press_data, rain_data,
                                          seasonality = TRUE, quart = "top")
arth_temp_res <- gtrend_weather_analysis(gtrends_data_arthritis, city_list_arth,
                                         temp_data, rain_data,
                                         seasonality = TRUE, quart = "top")


# =============================================================================

# 5. Compare trends (city level)
knee_hum_group <- group_comp(knee_hum_res[[1]])
knee_press_group <- group_comp(knee_press_res[[1]])
knee_temp_group <- group_comp(knee_temp_res[[1]])
hip_hum_group <- group_comp(hip_hum_res[[1]])
hip_press_group <- group_comp(hip_press_res[[1]])
hip_temp_group <- group_comp(hip_temp_res[[1]])
arth_hum_group <- group_comp(arth_hum_res[[1]])
arth_press_group <- group_comp(arth_press_res[[1]])
arth_temp_group <- group_comp(arth_temp_res[[1]])


# =============================================================================

# 5. Run linear regressions
arth_lm_temp_res <- gtrend_weather_analysis2(arth_temp_res)
arth_lm_press_res <- gtrend_weather_analysis2(arth_press_res)
knee_lm_temp_res <- gtrend_weather_analysis2(knee_temp_res)
knee_lm_press_res <- gtrend_weather_analysis2(knee_press_res)
hip_lm_temp_res <- gtrend_weather_analysis2(hip_temp_res)
hip_lm_press_res <- gtrend_weather_analysis2(hip_press_res)


# =============================================================================

# Find Mean and SD differences
var_mean <- function(x) {
  low = as.numeric(as.character(x[, 6]))
  high = as.numeric(as.character(x[, 5]))
  mean_diff = ((high / low) * 100) - 100
  mean_diff = mean(mean_diff)
  return(mean_diff)
}

var_sd <- function(x) {
  low = as.numeric(as.character(x[, 6]))
  high = as.numeric(as.character(x[, 5]))
  mean_diff = high - low
  sd_diff = sd(mean_diff)
  return(sd_diff)
}

knee_press_mean <- var_mean(knee_press_res[[1]])
knee_press_SD <- var_sd(knee_press_res[[1]])
knee_temp_mean <- var_mean(knee_temp_res[[1]])
knee_temp_SD <- var_sd(knee_temp_res[[1]])
hip_press_mean <- var_mean(hip_press_res[[1]])
hip_press_SD <- var_sd(hip_press_res[[1]])
hip_temp_mean <- var_mean(hip_temp_res[[1]])
hip_temp_SD <- var_sd(hip_temp_res[[1]])
arth_press_mean <- var_mean(arth_press_res[[1]])
arth_press_SD <- var_sd(arth_press_res[[1]])
arth_temp_mean <- var_mean(arth_temp_res[[1]])
arth_temp_SD <- var_sd(arth_temp_res[[1]])


# =============================================================================

# Test control variable
# RADIO searches
radio_press_res <- gtrend_weather_analysis(gtrends_data_radio, city_list_radio,
                                           press_data, rain_data,
                                           seasonality = TRUE, quart = "top")
radio_temp_res <- gtrend_weather_analysis(gtrends_data_radio, city_list_radio,
                                          temp_data, rain_data,
                                          seasonality = TRUE, quart = "top")

# Compare trends (city level)
radio_press_group <- group_comp(radio_press_res[[1]], hyp = "greater")
radio_temp_group <- group_comp(radio_temp_res[[1]], hyp = "less")
